import React, { useState } from 'react';
import axios from 'axios';
import { API_URL } from './config';

export default function Login(){
  const [u,setU]=useState(''); const [p,setP]=useState(''); const [remember,setRemember]=useState(true); const [msg,setMsg]=useState('');
  const submit = async ()=>{
    try {
      const res = await axios.post(API_URL + '/api/admin/login', { username: u, password: p });
      const token = res.data.token;
      if (remember) localStorage.setItem('admin_token', token); else sessionStorage.setItem('admin_token', token);
      window.location.href = '/secure-admin';
    } catch(e){ setMsg('Login failed'); }
  }
  return (<div style={{padding:20,fontFamily:'sans-serif'}}>
    <h1>Admin Login</h1>
    <input placeholder="username" value={u} onChange={e=>setU(e.target.value)} /><br/><br/>
    <input placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)} /><br/><br/>
    <label><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)} /> Remember Me</label><br/><br/>
    <button onClick={submit}>Login</button>
    <div style={{marginTop:12}}>{msg}</div>
  </div>);
}
