import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { API_URL } from './config';

function getToken(){ return localStorage.getItem('admin_token') || sessionStorage.getItem('admin_token'); }

export default function Admin(){
  const [totals,setTotals]=useState({red:0,blue:0,green:0,yellow:0});
  const [phase,setPhase]=useState('');
  const [players,setPlayers]=useState([]);
  const [msg,setMsg]=useState('');

  useEffect(()=>{
    const iv = setInterval(async ()=>{
      try {
        const p = await axios.get(API_URL + '/api/admin/players', { headers: { Authorization: 'Bearer ' + getToken() } });
        setPlayers(p.data.players || []);
      } catch(e) {}
      try {
        const t = await axios.get(API_URL + '/api/admin/totals', { headers: { Authorization: 'Bearer ' + getToken() } });
        setTotals(t.data.totals || {}); setPhase('RESULT');
      } catch(e){ setPhase('BETTING'); }
    }, 1500);
    return ()=>clearInterval(iv);
  },[]);

  const pick = async (color)=>{
    try {
      const res = await axios.post(API_URL + '/api/admin/pick', { color }, { headers: { Authorization: 'Bearer ' + getToken() } });
      setMsg('Picked: ' + res.data.winner);
    } catch(e){ setMsg('Pick error: ' + (e.response?.data?.error||e.message)); }
  };

  const logout = ()=>{ localStorage.removeItem('admin_token'); sessionStorage.removeItem('admin_token'); window.location.href='/secure-admin/login'; }

  return (<div style={{padding:20,fontFamily:'sans-serif'}}>
    <h1>Admin Panel</h1>
    <button onClick={logout}>Logout</button>
    <div style={{marginTop:12}}><strong>Phase:</strong> {phase}</div>
    <h3>Totals (visible during result):</h3>
    <ul>{Object.entries(totals).map(([k,v])=> <li key={k}>{k}: ₹{v}</li>)}</ul>
    <h3>Pick winner</h3>
    {['red','blue','green','yellow'].map(c=> <button key={c} onClick={()=>pick(c)} style={{marginRight:8}}>{c}</button>)}
    <h3 style={{marginTop:12}}>Players</h3>
    <ul>{players.map(p=> <li key={p.username}>{p.username}: ₹{p.balance}</li>)}</ul>
    <div style={{marginTop:12,fontWeight:'bold'}}>{msg}</div>
  </div>);
}
