import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import Admin from './Admin'
import Login from './Login'

function Router() {
  const path = window.location.pathname;
  if (path === '/secure-admin') return <Admin />;
  if (path === '/secure-admin/login') return <Login />;
  return <App />;
}

createRoot(document.getElementById('root')).render(<Router />);
