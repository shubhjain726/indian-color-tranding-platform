import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
import { API_URL } from './config';
import axios from 'axios';

const socket = io(API_URL);

export default function App(){
  const [phase, setPhase] = useState('BETTING');
  const [totals, setTotals] = useState({red:0,blue:0,green:0,yellow:0});
  const [token, setToken] = useState(localStorage.getItem('player_token') || null);
  const [username, setUsername] = useState(null);
  const [balance, setBalance] = useState(0);
  const [amount, setAmount] = useState(50);
  const [color, setColor] = useState('red');
  const [message, setMessage] = useState('');

  useEffect(()=>{
    socket.on('round:update', (r)=>{ setPhase(r.state || 'BETTING'); if (r.totals) setTotals(r.totals); });
    socket.on('bet:update', (t)=> setTotals(t));
    socket.on('round:resolved', (res)=> setMessage('Round '+res.round+' resolved. Winner: '+(res.winner||'None')));
    return ()=> socket.off();
  },[]);

  useEffect(()=>{ if (token) fetchMe(); }, [token]);

  async function fetchMe(){
    try {
      const res = await axios.get(API_URL + '/api/player/me', { headers: { Authorization: 'Bearer ' + token } });
      setUsername(res.data.username); setBalance(res.data.balance);
    } catch(e){ setMessage('Session expired or invalid. Please login again.'); localStorage.removeItem('player_token'); setToken(null); }
  }

  async function signup(u,p){
    try {
      const res = await axios.post(API_URL + '/api/signup', { username: u, password: p });
      setMessage('Signup ok. Please login.');
    } catch(e){ setMessage('Signup error: ' + (e.response?.data?.error||e.message)); }
  }
  async function login(u,p){
    try {
      const res = await axios.post(API_URL + '/api/login', { username: u, password: p });
      setToken(res.data.token); localStorage.setItem('player_token', res.data.token);
      setUsername(res.data.username); setBalance(res.data.balance);
      setMessage('Logged in as ' + res.data.username);
    } catch(e){ setMessage('Login failed'); }
  }

  async function demoCreate(){
    const res = await axios.post(API_URL + '/api/create-demo-player');
    localStorage.setItem('player_token', res.data.token);
    setToken(res.data.token); setUsername(res.data.username); setBalance(res.data.balance);
    setMessage('Demo player created: ' + res.data.username);
  }

  async function placeBet(c){
    if (!token) return setMessage('Login first');
    try {
      const res = await axios.post(API_URL + '/api/bet', { color: c, amount: Number(amount) }, { headers: { Authorization: 'Bearer ' + token } });
      setBalance(res.data.balance);
      setMessage('Bet placed on ' + c);
    } catch(e){ setMessage('Bet error: ' + (e.response?.data?.error||e.message)); }
  }

  return (
    <div style={{padding:20, fontFamily:'sans-serif'}}>
      <h1>Color Bet — Demo (Fake Money)</h1>
      {!username && <div style={{marginBottom:10}}>
        <button onClick={demoCreate}>Create Demo Player (quick)</button>
        <div style={{marginTop:8}}>Or Signup / Login</div>
        <div style={{display:'flex', gap:8, marginTop:8}}>
          <input id="su" placeholder="username" /> <input id="sp" placeholder="password" type="password" />
          <button onClick={()=>signup(document.getElementById('su').value, document.getElementById('sp').value)}>Sign up</button>
        </div>
        <div style={{display:'flex', gap:8, marginTop:8}}>
          <input id="lu" placeholder="username" /> <input id="lp" placeholder="password" type="password" />
          <button onClick={()=>login(document.getElementById('lu').value, document.getElementById('lp').value)}>Login</button>
        </div>
      </div>}
      {username && <div>Player: <b>{username}</b> — Balance: <b>₹{balance}</b></div>}
      <div style={{marginTop:12}}>Phase: <b>{phase}</b></div>
      <div style={{display:'flex', gap:10, marginTop:12}}>
        {['red','blue','green','yellow'].map(c=> (
          <div key={c} style={{border:'1px solid #ddd', padding:10, width:160}}>
            <div style={{height:60, background:c, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center'}}>{c.toUpperCase()}</div>
            <div style={{marginTop:8}}>Total: ₹{totals[c]}</div>
            <div style={{marginTop:8}}>
              <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} style={{width:80}}/> 
              <button onClick={()=>placeBet(c)} disabled={phase!=='BETTING'} style={{marginLeft:6}}>Bet</button>
            </div>
          </div>
        ))}
      </div>
      <div style={{marginTop:12}}><strong>Message:</strong> {message}</div>
      <div style={{marginTop:12}}>Admin panel (hidden): <a href="/secure-admin">/secure-admin</a></div>
    </div>
  );
}
