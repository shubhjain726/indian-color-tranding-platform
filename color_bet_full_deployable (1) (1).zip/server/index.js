
/**
Color Bet Backend (demo)
- Uses MongoDB (MONGODB_URI env var)
- Admin credentials are in env: ADMIN_USER, ADMIN_PASS (for demo you can set)
- JWT_SECRET env var required
- Timers: BETTING_DURATION_MS and RESULT_DURATION_MS env or defaults (30s/10s)
*/
const express = require('express');
const http = require('http');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/colorbet_demo';
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change';
const ADMIN_USER = process.env.ADMIN_USER || 'Shubhjain77848';
const ADMIN_PASS_RAW = process.env.ADMIN_PASS || '#Shubh jain#*(29)'; // raw - we'll store hashed for comparison

const BETTING_DURATION_MS = parseInt(process.env.BETTING_DURATION_MS) || 30*1000;
const RESULT_DURATION_MS = parseInt(process.env.RESULT_DURATION_MS) || 10*1000;

mongoose.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=>console.log('Connected to MongoDB'))
  .catch(err=>console.error('MongoDB connection error', err));

// Schemas
const UserSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  passwordHash: String,
  balance: { type: Number, default: 1000 }
});
const BetSchema = new mongoose.Schema({
  userId: String,
  color: String,
  amount: Number,
  round: Number,
  createdAt: { type: Date, default: Date.now }
});
const RoundSchema = new mongoose.Schema({
  round: Number,
  state: String, // BETTING | RESULT | RESOLVED
  totals: { red: Number, blue: Number, green: Number, yellow: Number },
  winner: { type: String, default: null },
  startedAt: Date
});

const User = mongoose.model('User', UserSchema);
const Bet = mongoose.model('Bet', BetSchema);
const Round = mongoose.model('Round', RoundSchema);

// ensure admin password hashed for simple compare (demo)
let ADMIN_PASS_HASH = null;
(async ()=>{ ADMIN_PASS_HASH = await bcrypt.hash(ADMIN_PASS_RAW, 10); })();

// current round state in-memory for fast updates (persist core to DB too)
let currentRound = { round: 1, state: 'BETTING', totals: { red:0, blue:0, green:0, yellow:0 }, winner: null };
let timerHandles = {}

// initialize or load latest round from DB
async function initRound() {
  const last = await Round.findOne().sort({ round: -1 }).lean();
  if (last) {
    currentRound.round = last.round + 1;
  } else {
    currentRound.round = 1;
  }
  currentRound.state = 'BETTING';
  currentRound.totals = { red:0, blue:0, green:0, yellow:0 };
  currentRound.winner = null;
  await Round.create({ round: currentRound.round, state: 'BETTING', totals: currentRound.totals, startedAt: new Date() });
  scheduleTimers();
}
function scheduleTimers() {
  clearTimers();
  timerHandles.betClose = setTimeout(()=>{
    currentRound.state = 'RESULT';
    io.emit('round:update', currentRound);
    // after result duration, auto-resolve as no winner if admin doesn't pick
    timerHandles.resultClose = setTimeout(async ()=>{
      if (currentRound.state === 'RESULT') {
        await resolveRound(null);
      }
    }, RESULT_DURATION_MS + 200);
  }, BETTING_DURATION_MS + 200);
  io.emit('round:update', currentRound);
}
function clearTimers() {
  if (timerHandles.betClose) clearTimeout(timerHandles.betClose);
  if (timerHandles.resultClose) clearTimeout(timerHandles.resultClose);
}

// resolve round
async function resolveRound(winningColor) {
  currentRound.state = 'RESOLVED';
  currentRound.winner = winningColor;
  // process payouts
  const bets = await Bet.find({ round: currentRound.round }).lean();
  for (const b of bets) {
    const user = await User.findOne({ username: b.userId });
    if (!user) continue;
    if (winningColor && b.color === winningColor) {
      user.balance = (user.balance || 0) + (b.amount * 2);
      await user.save();
    }
    // losers already deducted at bet time
  }
  // store round record
  await Round.create({ round: currentRound.round, state: 'RESOLVED', totals: currentRound.totals, winner: currentRound.winner, startedAt: new Date() });
  io.emit('round:resolved', { round: currentRound.round, winner: currentRound.winner, totals: currentRound.totals });
  // prepare next round after short delay
  setTimeout(async ()=>{
    currentRound.round += 1;
    currentRound.state = 'BETTING';
    currentRound.totals = { red:0, blue:0, green:0, yellow:0 };
    currentRound.winner = null;
    await Round.create({ round: currentRound.round, state: 'BETTING', totals: currentRound.totals, startedAt: new Date() });
    io.emit('round:update', currentRound);
    scheduleTimers();
  }, 5000);
}

// API endpoints

// player signup/login (simple password storage - uses bcrypt)
app.post('/api/signup', async (req, res)=>{
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'missing' });
  const existing = await User.findOne({ username });
  if (existing) return res.status(400).json({ error: 'user-exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ username, passwordHash: hash, balance: 1000 });
  return res.json({ ok: true, username: user.username, balance: user.balance });
});
app.post('/api/login', async (req, res)=>{
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(400).json({ error: 'invalid' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: 'invalid' });
  const token = jwt.sign({ user: user.username, type: 'player' }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({ ok: true, token, username: user.username, balance: user.balance });
});

// create player quick (for demo) - returns username/token
app.post('/api/create-demo-player', async (req, res)=>{
  const id = 'user' + Math.random().toString(36).slice(2,8);
  const password = 'demo';
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ username: id, passwordHash: hash, balance: 1000 });
  const token = jwt.sign({ user: user.username, type: 'player' }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({ ok: true, username: user.username, token, balance: user.balance });
});

// auth middleware for players
function authPlayer(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'no-token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'bad' });
  try {
    const data = jwt.verify(parts[1], JWT_SECRET);
    if (data.type !== 'player') return res.status(401).json({ error: 'not-player' });
    req.player = data.user;
    next();
  } catch(e){ return res.status(401).json({ error: 'invalid' }); }
}

// place bet
app.post('/api/bet', authPlayer, async (req, res)=>{
  const { color, amount } = req.body;
  const username = req.player;
  if (currentRound.state !== 'BETTING') return res.status(400).json({ error: 'betting-closed' });
  if (!['red','blue','green','yellow'].includes(color)) return res.status(400).json({ error: 'invalid-color' });
  const user = await User.findOne({ username });
  if (!user) return res.status(404).json({ error: 'no-user' });
  if (user.balance < amount) return res.status(400).json({ error: 'insufficient' });
  user.balance -= amount;
  await user.save();
  await Bet.create({ userId: user.username, color, amount, round: currentRound.round });
  currentRound.totals[color] += Number(amount);
  io.emit('bet:update', { totals: currentRound.totals });
  return res.json({ ok: true, balance: user.balance });
});

// get player info
app.get('/api/player/me', authPlayer, async (req, res)=>{
  const user = await User.findOne({ username: req.player });
  if (!user) return res.status(404).json({ error: 'no-user' });
  return res.json({ username: user.username, balance: user.balance });
});

// Admin login (hardcoded credentials via env)
app.post('/api/admin/login', async (req, res)=>{
  const { username, password } = req.body;
  if (username !== ADMIN_USER) return res.status(401).json({ error: 'invalid' });
  const ok = await bcrypt.compare(password, ADMIN_PASS_HASH || ADMIN_PASS_RAW);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ user: username, type: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({ ok: true, token });
});

// admin middleware
function authAdmin(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'no-token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'bad' });
  try {
    const data = jwt.verify(parts[1], JWT_SECRET);
    if (data.type !== 'admin') return res.status(401).json({ error: 'not-admin' });
    req.admin = data.user;
    next();
  } catch(e){ return res.status(401).json({ error: 'invalid' }); }
}

// admin endpoints
app.get('/api/admin/totals', authAdmin, async (req, res)=>{
  if (currentRound.state !== 'RESULT') return res.status(400).json({ error: 'not-result' });
  return res.json({ totals: currentRound.totals, round: currentRound.round });
});
app.post('/api/admin/pick', authAdmin, async (req, res)=>{
  const { color } = req.body;
  if (currentRound.state !== 'RESULT') return res.status(400).json({ error: 'not-result' });
  if (!['red','blue','green','yellow'].includes(color)) return res.status(400).json({ error: 'invalid' });
  await resolveRound(color);
  return res.json({ ok: true, winner: color });
});
app.get('/api/admin/players', authAdmin, async (req, res)=>{
  const users = await User.find({}, 'username balance').lean();
  return res.json({ players: users });
});

// socket
io.on('connection', (socket)=>{
  socket.emit('round:update', currentRound);
  socket.on('request:round', ()=> socket.emit('round:update', currentRound));
});

// start server
const PORT = process.env.PORT || 4000;
server.listen(PORT, ()=>{
  console.log('Server running on', PORT);
  initRound();
});
